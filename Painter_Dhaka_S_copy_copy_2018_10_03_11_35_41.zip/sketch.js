 let bubbles = [];


function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 10; i++) {
    let x = random(width);
    let y = random(height);
    let r = random(20, 60);
    let b = new Bubble(x, y, r);
    bubbles.push(b);
  }
}

function mousePressed() {

  for (let i = bubbles.length - 1; i >= 0; i--) {
    if (bubbles[i].click(mouseX, mouseY)) {
      bubbles.splice(i, 1);
    }
  }
}

function draw() {
  background(0);
var other;
  let b;
  for(other of bubbles){
  for(b of bubbles){
  if(b.intersects(other)&&(b!==other)){
  background(12,231,123);
  }
  }
  }

  for (let i = 0; i < bubbles.length; i++) {
    bubbles[i].rollOver(mouseX, mouseY);
    bubbles[i].show();
    bubbles[i].move();
  }


}

class Bubble { ///////////////////////////////////////////////////////////
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.brightness = 0;
  }
  intersects(other) {

    return ((other.r + this.r) > dist(other.x, other.y, this.x, this.y))
  }
  rollOver(px, py) {
    let d = dist(px, py, this.x, this.y);
    if (d < this.r) {
      this.brightness = 255;
    } else {
      this.brightness = 0;
    }
  }
  move() {
    this.x = this.x + random(-2, 2);
    this.y = this.y + random(-2, 2);
  }
  click(pmx, pmy) {
    let d = dist(pmx, pmy, this.x, this.y);
    if (d < this.r) {
      return true;
    }
  }
  show() {
    stroke(255);
    strokeWeight(4);
    fill(this.brightness, 125);
    ellipse(this.x, this.y, this.r * 2, this.r * 2);
  }
}