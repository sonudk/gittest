var mousex = 23;
function setup(){
background(23,23,233);
}
function draw(){
	fill(12,122,234,120);
  ellipse(mousex,150,12);
}
function mousePressed(){
background(23,23,233);
  background(Math.random() * 200, Math.random() * 235, Math.random() * 238);

}