var mousex;
var mousey;
function setup() {
  createCanvas(600, 400);
  //background(220, 235, 238);
  
}

function draw() {
    background(0, 0, 0);
  mousey = Math.floor(Math.random()*390);
  mousex = Math.floor(Math.random()*590);
  rect(mousey,mousex,10,10);
  ellipse(mousex, mousey, 15, 15);
  fill(Math.random() * 225, Math.random() * 223, Math.random() * 242, Math.random() * 255);
  noStroke();
  
  rect(mousey, mousex, 12, 390);
}

function mousePressed() {
 background(Math.random() * 200, Math.random() * 235, Math.random() * 238);


}